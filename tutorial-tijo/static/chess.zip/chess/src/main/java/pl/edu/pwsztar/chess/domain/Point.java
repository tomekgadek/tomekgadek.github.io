package pl.edu.pwsztar.chess.domain;

public record Point(int x, int y) {
}
