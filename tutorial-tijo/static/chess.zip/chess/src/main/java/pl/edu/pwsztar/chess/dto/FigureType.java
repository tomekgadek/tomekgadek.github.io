package pl.edu.pwsztar.chess.dto;

public enum FigureType {
    KING, QUEEN, ROOK, BISHOP, KNIGHT, PAWN
}
