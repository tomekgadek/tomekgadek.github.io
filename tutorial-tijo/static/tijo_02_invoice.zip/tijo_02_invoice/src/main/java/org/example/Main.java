package org.example;

public class Main {
    public static void main( String[] args ) {

        float[] amounts = { 400.00f, 600.00f, 300.00f, 700.00f, 600.00f };
        Invoice[] invoices = new Invoice[5];

        for(int i=0; i < invoices.length; i++) {
            invoices[i] = new Invoice(String.valueOf(i + 1), amounts[i]);
            System.out.println(invoices[i]);
        }
    }
}