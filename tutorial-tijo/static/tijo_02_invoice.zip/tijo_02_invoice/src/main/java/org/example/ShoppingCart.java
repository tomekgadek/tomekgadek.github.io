package org.example;

public class ShoppingCart {
    private String productName;
    private double price;
    private int quantity;

    boolean addProduct(String productName, double price, int quantity) {

        if(price < 0 || quantity < 0) {
            return false;
        }

        this.productName = productName;
        this.price = price;
        this.quantity = quantity;

        return true;
    }
}
