package org.example;

import java.util.Calendar;

record Invoice(String id, float amount) {
    static String prefix =
            Calendar.getInstance().get(Calendar.YEAR) + String.valueOf(Calendar.getInstance().get(Calendar.MONTH)+1);
    public Invoice {
        id = prefix + id.trim();

        if(amount < 0) {
            throw new IllegalArgumentException("values not allowed");
        }
    }

    public Invoice(String id){
        this(id,0.0f);
    }
}
