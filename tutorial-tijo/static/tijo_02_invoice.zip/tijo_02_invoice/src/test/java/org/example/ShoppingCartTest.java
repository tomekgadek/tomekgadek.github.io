package org.example;

class ShoppingCartTest {

    static void testAdd2TimesCocaColaToShoppingCart() {
        // Arrange
        var cart = new ShoppingCart();
        var product = "Coca-Cola";
        var price = 4.0;
        var quantity = 2;

        // Act
        var addResult = cart.addProduct(product, price, quantity);

        // Assert
        assert addResult : "should add coca-cola (quantity = 2) to cart";
    }

    static void testAdd1TimesCocaColaToShoppingCart() {
        // Arrange
        var cart = new ShoppingCart();
        var product = "Pizza";
        var price = 23.0;
        var quantity = 1;

        // Act
        var addResult = cart.addProduct(product, price, quantity);

        // Assert
        assert addResult : "should add coca-cola (quantity = 1) to cart";
    }

    static void testAddCocaColaWithBadValuePriceAndQuantityToShoppingCart() {
        // Arrange
        var cart = new ShoppingCart();
        var product = "Coca-Cola";
        var price = -4.0;
        var quantity = -1;

        // Act
        var addResult = cart.addProduct(product, price, quantity);

        // Assert
        assert !addResult : "should add coca-cola (quantity = -1, price = - 1) to cart";
    }

    public static void main(String[] args) {
        ShoppingCartTest.testAdd1TimesCocaColaToShoppingCart();
        ShoppingCartTest.testAdd2TimesCocaColaToShoppingCart();
        ShoppingCartTest.testAddCocaColaWithBadValuePriceAndQuantityToShoppingCart();
    }
}
