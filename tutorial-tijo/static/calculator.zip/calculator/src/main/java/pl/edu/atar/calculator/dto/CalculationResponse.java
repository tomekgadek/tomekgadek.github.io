package pl.edu.atar.calculator.dto;

public record CalculationResponse(Double result) {
}
