package pl.edu.atar.calculator.operations;

public interface Operation {
    double calculate(double first, double second);
}
