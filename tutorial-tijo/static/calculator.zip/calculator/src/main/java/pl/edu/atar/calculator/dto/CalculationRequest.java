package pl.edu.atar.calculator.dto;

public record CalculationRequest (Double a, Double b, String operation) {
}
