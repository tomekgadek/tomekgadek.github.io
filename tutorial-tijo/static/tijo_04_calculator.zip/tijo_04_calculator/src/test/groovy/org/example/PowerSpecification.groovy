package org.example

import spock.lang.Specification

// 1. Dodac POM do pobrania
// 2. Pokazac te 2 klasy / Pokazac filmik, jak uruchamiac tetsy jednostkowe
// 2a. Wytlumaczyc, jak dzialaja tetsy z tabelka / parametryzowane
// Jak umieszczac pliki produkcyjne i testowe???
// 3. Zadac zadanie z klasa Calculator
// 4. Zadac zadanie - jedno z poprzednich
// 5. Uzywamy GiTa

class PowerSpecification extends Specification {

    def "numbers to the power of two"(int a, int b, int c) {
        expect:
            Math.pow(a, b) == c // It is assertion!

        where:
            a | b | c
            1 | 2 | 1
            2 | 2 | 4
            3 | 2 | 9
    }
}
