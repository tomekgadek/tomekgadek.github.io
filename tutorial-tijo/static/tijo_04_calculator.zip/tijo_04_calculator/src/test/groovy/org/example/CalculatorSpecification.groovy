package org.example

import spock.lang.Specification

class CalculatorSpecification extends Specification {

    def "one plus two should equal three"() {

        given: "Prepare two variables 'one' and 'two'"
            def calculator = new Calculator()
            def one = 1.0
            def two = 2.0

        when: "Try add two values one = 1 and two = 2"
            def result = calculator.add(one, two)

        then: "The result of addition is 3"
            result.toDouble() == 3.0
    }

    def "one divide zero should throw exception"() {

        given: "Prepare two variables 'one' and 'zero'"
        def calculator = new Calculator()
        def one = 1.0
        def zero = 0.0

        when: "Try div two values one = 1 and two = 0"
        def result = calculator.div(one, zero)

        then: "Throw IllegalArgumentException"
        thrown(IllegalArgumentException)
    }
}

