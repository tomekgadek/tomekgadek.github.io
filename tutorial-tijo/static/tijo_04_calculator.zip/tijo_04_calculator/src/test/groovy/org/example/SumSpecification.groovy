package org.example

import spock.lang.Specification

class SumSpecification extends Specification {

    def "one plus two should equal three"() {

        given: "Prepare two variables 'one' and 'two'"
            def one = 1
            def two = 2

        when: "Try add two values one = 1 and two = 2"
            def result = one + two
        then: "The result of addition is 3"
            result == 3 // It is assertion!
    }
}
