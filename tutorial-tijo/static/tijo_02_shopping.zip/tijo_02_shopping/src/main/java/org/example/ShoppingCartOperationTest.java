package org.example;

import java.util.Arrays;
import java.util.List;

class ShoppingCartOperationTest {

    void testAddProductToCartOk() {
        // Arrange
        var shoppingCart = new ShoppingCartOperationImpl();

        // Act
        var result = shoppingCart.addProduct("Coca-Cola", 200, 2);

        // Assert
        assert result : "Should add product to cart";
    }

    void testAddProductToCartFail() {
        // Arrange
        var shoppingCart = new ShoppingCartOperationImpl();

        // Act
        var result = shoppingCart.addProduct("Coca-Cola", 200, -1);

        // Assert
        assert !result : "Should not add product with negative quantity";
    }

    void testRemoveProductFromCartOk() {
        // Arrange
        var shoppingCart = new ShoppingCartOperationImpl();
        shoppingCart.addProduct("Coca-Cola", 200, 1);

        // Act
        var result = shoppingCart.removeProduct("Coca-Cola");

        // Assert
        assert result : "Should remove product";
    }

    void testRemoveProductFromCartFail() {
        // Arrange
        var shoppingCart = new ShoppingCartOperationImpl();
        shoppingCart.addProduct("Coca-Cola", 200, 1);

        // Act
        var result = shoppingCart.removeProduct("Coca-Col");

        // Assert
        assert !result : "Should not remove product";
    }

    void testUpdateQuantityInCartOk() {
        // Arrange
        var shoppingCart = new ShoppingCartOperationImpl();
        shoppingCart.addProduct("Coca-Cola", 200, 1);

        // Act
        var result = shoppingCart.updateQuantity("Coca-Cola", 3);

        // Assert
        assert result : "Should update quantity";
    }

    void testUpdateQuantityInCartFail() {
        // Arrange
        var shoppingCart = new ShoppingCartOperationImpl();
        shoppingCart.addProduct("Coca-Cola", 200, 1);

        // Act
        var result = shoppingCart.updateQuantity("Coca-Col", 3);

        // Assert
        assert !result : "Should not update quantity";
    }

    void testGetProductsFromCartOk() {
        // Arrange
        var shoppingCart = new ShoppingCartOperationImpl();
        shoppingCart.addProduct("Coca-Cola", 200, 1);
        shoppingCart.addProduct("Fanta", 100, 2);
        shoppingCart.addProduct("Sprite", 150, 3);

        List<String> products = Arrays.asList("Coca-Cola", "Fanta", "Sprite");

        // Act
        var resultProducts = shoppingCart.getProducts();

        // Assert
        for (var product : products) {
            assert resultProducts.contains(product) : "Should return all products from cart";
        }

    }

}
