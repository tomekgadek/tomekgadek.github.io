package org.example;

import java.util.List;

public interface ShoppingCartOperation {

    // Dodawanie produktu do koszyka
    boolean addProduct(String productName, int price, int quantity);
    
    // Usuwanie produktu z koszyka
    boolean removeProduct(String productName);

    // Aktualizacja ilości produktu w koszyku
    boolean updateQuantity(String productName, int newQuantity);

    // Pobieranie nazw produktów z koszyka
    List<String> getProducts();

    // Pobieranie liczby produktów znajdujących się w koszyku
    int countProducts();

    // Pobieranie sumy cen produktów w koszyku
    int getTotalPrice();

    // Zastosowanie kuponu rabatowego
    boolean applyDiscountCode(String discountCode);

    // Realizacja zamówienia
    boolean checkout();
}
