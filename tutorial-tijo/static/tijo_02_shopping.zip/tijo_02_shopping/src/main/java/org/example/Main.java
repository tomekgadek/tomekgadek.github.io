package org.example;

public class Main {
    public static void main(String[] args) {

        new ShoppingCartOperationTest().testAddProductToCartOk();
        new ShoppingCartOperationTest().testAddProductToCartFail();
        new ShoppingCartOperationTest().testRemoveProductFromCartOk();
        new ShoppingCartOperationTest().testRemoveProductFromCartFail();
        new ShoppingCartOperationTest().testUpdateQuantityInCartOk();
        new ShoppingCartOperationTest().testUpdateQuantityInCartFail();
        new ShoppingCartOperationTest().testGetProductsFromCartOk();

    }
}