package org.example;

import java.util.ArrayList;
import java.util.List;

public class ShoppingCartOperationImpl implements ShoppingCartOperation {

    private List<Product> products = new ArrayList<>();

    @Override
    public boolean addProduct(String productName, int price, int quantity) {
        if(price < 0 || quantity < 0) {
            return false;
        }

        products.add(new Product(productName, price, quantity));

        return true;
    }

    @Override
    public boolean removeProduct(String productName) {

        if(products.stream().anyMatch(product -> product.productName().equals(productName))) {
            products = new ArrayList<>(products.stream()
                    .filter(product -> !product.productName().equals(productName))
                    .toList());
            return true;
        }

        return false;
    }

    @Override
    public boolean updateQuantity(String productName, int newQuantity) {

        var product = products.stream().filter(prod -> prod.productName().equals(productName)).findFirst();

        if(product.isPresent()) {
            product.map(obj -> new Product(productName, obj.price(), newQuantity));
            return true;
        }

        return false;
    }

    @Override
    public List<String> getProducts() {
        return products.stream().map(Product::productName).toList();
    }

    @Override
    public int countProducts() {
        return 0;
    }

    @Override
    public int getTotalPrice() {
        return 0;
    }

    @Override
    public boolean applyDiscountCode(String discountCode) {
        return false;
    }

    @Override
    public boolean checkout() {
        return false;
    }
}
