package org.example;

record Product(String productName, int price, int quantity) {
}
